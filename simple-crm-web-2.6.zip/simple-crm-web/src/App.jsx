import { useState, useContext } from "react";
import { AuthContext } from "./contexts/AuthContext";
import { CustomerContext } from "./contexts/CustomerContext";
import CustomerCard from "./components/CustomerCard";
import SearchBar from "./components/SearchBar";
import CustomerDetail from "./components/CustomerDetail";
import Spinner from "./components/Spinner";

import "./App.css";
import LoginPage from "./components/LoginPage";
import Header from "./components/Header";

export const API_BASE = "http://localhost:3001";

const INITIAL_FORM = {
  firstName: "",
  lastName: "",
  email: "",
  tags: [],
  status: "active",
};

const ALL_TAGS = ["VIP", "Lead", "Referral"];

function App() {

  console.log("App rendered");
  const { user } = useContext(AuthContext);
  const {
    filteredCustomers,
    loading,
    error,
    submitting,
    showForm,
    searchTerm,
    statusFilter,
    selectedId,
    addCustomer,
    toggleForm,
    setSearchTerm,
    setStatusFilter,
    setSelectedId,
  } = useContext(CustomerContext);
  const [form, setForm] = useState(INITIAL_FORM);

  const handleChange = (e) => {
    // [e.target.name] evaluates to the value e.g. firstName: "a"
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleTagToggle = (tag) => {
    setForm((prev) => ({
      ...prev,
      // Set tags based on whether the tag is already included in the form's tags array
      // prev.tags.includes(tag) means the tag is already selected
      tags: prev.tags.includes(tag)
        ? prev.tags.filter((t) => t !== tag)
        : [...prev.tags, tag],
    }));
  };

  const handleAddCustomer = async (e) => {
    e.preventDefault();
    const newCustomer = {
      firstName: form.firstName,
      lastName: form.lastName,
      email: form.email,
      phone: "",
      status: form.status,
      tags: form.tags,
      company: "",
      notes: "",
      createdAt: new Date().toISOString().slice(0, 10),
    };

    await addCustomer(newCustomer);
    setForm(INITIAL_FORM);
  };

  if (!user) return <LoginPage />;
  if (loading) return <Spinner />;
  if (error) return <p className="status-message error">Error: {error}</p>;

  return (
    <div className="simple-crm">
      <Header />
      <button className="toggle-form-btn" onClick={toggleForm}>
        {showForm ? "Cancel" : "Add Customer"}
      </button>

      {showForm && (
        <form onSubmit={handleAddCustomer} className="add-customer-form">
          <h3>Add New Customer</h3>
          <div className="form-field">
            <label htmlFor="firstName">First name</label>
            <input
              id="firstName"
              name="firstName"
              type="text"
              placeholder="e.g. Sarah"
              value={form.firstName}
              onChange={handleChange}
              required
            />
          </div>
          <div className="form-field">
            <label htmlFor="lastName">Last name</label>
            <input
              id="lastName"
              name="lastName"
              type="text"
              placeholder="e.g. Chen"
              value={form.lastName}
              onChange={handleChange}
              required
            />
          </div>

          <div className="form-field">
            <label htmlFor="email">Email</label>
            <input
              id="email"
              name="email"
              type="email"
              placeholder="e.g. sarah.chen@email.com"
              value={form.email}
              onChange={handleChange}
              required
            />
          </div>

          <div className="form-field">
            <label>Tags</label>
            <div className="tag-options">
              {ALL_TAGS.map((tag) => (
                <button
                  key={tag}
                  type="button"
                  onClick={() => handleTagToggle(tag)}
                  className={`tag-toggle${form.tags.includes(tag) ? " tag-toggle-active" : ""}`}
                >
                  {tag}
                </button>
              ))}
            </div>
          </div>

          <div className="form-field">
            <label htmlFor="status">Status</label>
            <select
              id="status"
              name="status"
              value={form.status}
              onChange={handleChange}
            >
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
            </select>
          </div>

          <button type="submit" className="submit-button" disabled={submitting}>
            {submitting ? "Adding..." : "Add Customer"}
          </button>
        </form>
      )}

      <div className="crm-layout">
        <div className="customer-panel">
          <SearchBar searchTerm={searchTerm} onSearch={setSearchTerm} />
          <div className="filter-bar">
            {["all", "active", "inactive"].map((f) => (
              <button
                key={f}
                className={`filter-btn${statusFilter === f ? " filter-btn-active" : ""}`}
                onClick={() => setStatusFilter(f)}
              >
                {f.charAt(0).toUpperCase() + f.slice(1)}
              </button>
            ))}
          </div>
          <div className="customer-list">
            <h2>Customers ({filteredCustomers.length})</h2>

            {filteredCustomers.length === 0 ? (
              <p className="empty-state">
                {searchTerm
                  ? "No customers match your search."
                  : "No customers yet. Add one above!"}
              </p>
            ) : (
              <div className="customers">
                {filteredCustomers.map((customer) => (
                  <CustomerCard
                    key={customer.id}
                    customer={customer}
                    onSelect={setSelectedId}
                    isSelected={selectedId === customer.id}
                  />
                ))}
              </div>
            )}
          </div>
        </div>

        <CustomerDetail selectedId={selectedId} />
      </div>
    </div>
  );
}

export default App;
